package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends Object{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4a.StandardBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) throws Exception{
        try {
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            ba.raiseEvent(null, "appstart", (Object)args);
        } catch (Throwable t) {
			BA.printException(t, true);
		
        } finally {
            anywheresoftware.b4a.keywords.Common.LogDebug("Program terminated (StartMessageLoop was not called).");
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static b4j.example.httputils2service _httputils2service = null;
public static String  _appstart(String[] _args) throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="Sub AppStart (Args() As String)";
 //BA.debugLineNum = 12;BA.debugLine="Log(\"Hello world!!!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("065537","Hello world!!!",0);
 //BA.debugLineNum = 15;BA.debugLine="LogColor(\"xDownload01下載程序-執行\",0xFFFC07CE)";
anywheresoftware.b4a.keywords.Common.LogImpl("065540","xDownload01下載程序-執行",((int)0xfffc07ce));
 //BA.debugLineNum = 16;BA.debugLine="xDownload01		'google網站";
_xdownload01();
 //BA.debugLineNum = 18;BA.debugLine="LogColor(\"xDownload02下載程序-執行\",0xFF0733FC)";
anywheresoftware.b4a.keywords.Common.LogImpl("065543","xDownload02下載程序-執行",((int)0xff0733fc));
 //BA.debugLineNum = 19;BA.debugLine="xDownload02		'B4X網站";
_xdownload02();
 //BA.debugLineNum = 21;BA.debugLine="Log(\"***AppStart End***\")";
anywheresoftware.b4a.keywords.Common.LogImpl("065546","***AppStart End***",0);
 //BA.debugLineNum = 22;BA.debugLine="LogColor(\"碰上StartMessageLoop,<非同步程序>排隊執行\",0xFFFF0";
anywheresoftware.b4a.keywords.Common.LogImpl("065547","碰上StartMessageLoop,<非同步程序>排隊執行",((int)0xffff0000));
 //BA.debugLineNum = 23;BA.debugLine="LogColor(\"碰上StopMessageLoop, <程序> 才會將結束\",0xFFFF00";
anywheresoftware.b4a.keywords.Common.LogImpl("065548","碰上StopMessageLoop, <程序> 才會將結束",((int)0xffff0000));
 //BA.debugLineNum = 24;BA.debugLine="StartMessageLoop";
anywheresoftware.b4a.keywords.Common.StartMessageLoop(ba);
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _download01() throws Exception{
ResumableSub_download01 rsub = new ResumableSub_download01(null);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_download01 extends BA.ResumableSub {
public ResumableSub_download01(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
boolean _isok = false;
b4j.example.httpjob _j = null;
b4j.example.httpjob _job = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 39;BA.debugLine="LogColor(\"download01 ==>\",0xFFFC07CE)";
anywheresoftware.b4a.keywords.Common.LogImpl("03604481","download01 ==>",((int)0xfffc07ce));
 //BA.debugLineNum = 41;BA.debugLine="Dim IsOK As Boolean";
_isok = false;
 //BA.debugLineNum = 42;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
 //BA.debugLineNum = 43;BA.debugLine="j.Initialize(\"\",Me)";
_j._initialize /*String*/ (ba,"",main.getObject());
 //BA.debugLineNum = 44;BA.debugLine="j.Download(\"https://google.com\")";
_j._download /*String*/ ("https://google.com");
 //BA.debugLineNum = 45;BA.debugLine="wait for (j) JobDone(job As HttpJob)	'不加 StartMes";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 7;
return;
case 7:
//C
this.state = 1;
_job = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 46;BA.debugLine="If job.Success Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_job._success /*boolean*/ ) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 47;BA.debugLine="LogColor(\"google網站正常!!\",0xFFFC07CE)";
anywheresoftware.b4a.keywords.Common.LogImpl("03604489","google網站正常!!",((int)0xfffc07ce));
 //BA.debugLineNum = 48;BA.debugLine="IsOK=True";
_isok = anywheresoftware.b4a.keywords.Common.True;
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 50;BA.debugLine="IsOK=False";
_isok = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 51;BA.debugLine="LogColor(\"google網站有問題???\",0xFFFC07CE)";
anywheresoftware.b4a.keywords.Common.LogImpl("03604493","google網站有問題???",((int)0xfffc07ce));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 54;BA.debugLine="LogColor(\"download01 Finish~~~\",0xFFFC07CE)";
anywheresoftware.b4a.keywords.Common.LogImpl("03604496","download01 Finish~~~",((int)0xfffc07ce));
 //BA.debugLineNum = 59;BA.debugLine="Return IsOK";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_isok));return;};
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _jobdone(b4j.example.httpjob _job) throws Exception{
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _download02() throws Exception{
ResumableSub_download02 rsub = new ResumableSub_download02(null);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_download02 extends BA.ResumableSub {
public ResumableSub_download02(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
int _i = 0;
boolean _isok = false;
b4j.example.httpjob _j = null;
b4j.example.httpjob _job = null;
int step2;
int limit2;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 75;BA.debugLine="LogColor(\"download02 ==>\",0xFF0733FC)";
anywheresoftware.b4a.keywords.Common.LogImpl("03735553","download02 ==>",((int)0xff0733fc));
 //BA.debugLineNum = 79;BA.debugLine="For i = 1 To 5";
if (true) break;

case 1:
//for
this.state = 4;
step2 = 1;
limit2 = (int) (5);
_i = (int) (1) ;
this.state = 11;
if (true) break;

case 11:
//C
this.state = 4;
if ((step2 > 0 && _i <= limit2) || (step2 < 0 && _i >= limit2)) this.state = 3;
if (true) break;

case 12:
//C
this.state = 11;
_i = ((int)(0 + _i + step2)) ;
if (true) break;

case 3:
//C
this.state = 12;
 //BA.debugLineNum = 80;BA.debugLine="Log(i)";
anywheresoftware.b4a.keywords.Common.LogImpl("03735558",BA.NumberToString(_i),0);
 //BA.debugLineNum = 81;BA.debugLine="Sleep(1000)    '<<-- Displaying Only First i=1";
anywheresoftware.b4a.keywords.Common.Sleep(ba,this,(int) (1000));
this.state = 13;
return;
case 13:
//C
this.state = 12;
;
 if (true) break;
if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 86;BA.debugLine="Dim IsOK As Boolean";
_isok = false;
 //BA.debugLineNum = 87;BA.debugLine="Dim j As HttpJob";
_j = new b4j.example.httpjob();
 //BA.debugLineNum = 88;BA.debugLine="j.Initialize(\"\",Me)";
_j._initialize /*String*/ (ba,"",main.getObject());
 //BA.debugLineNum = 89;BA.debugLine="j.Download(\"https://www.b4x.com/\")";
_j._download /*String*/ ("https://www.b4x.com/");
 //BA.debugLineNum = 90;BA.debugLine="wait for (j) JobDone(job As HttpJob)	'不加 StartMes";
anywheresoftware.b4a.keywords.Common.WaitFor("jobdone", ba, this, (Object)(_j));
this.state = 14;
return;
case 14:
//C
this.state = 5;
_job = (b4j.example.httpjob) result[0];
;
 //BA.debugLineNum = 91;BA.debugLine="If job.Success Then";
if (true) break;

case 5:
//if
this.state = 10;
if (_job._success /*boolean*/ ) { 
this.state = 7;
}else {
this.state = 9;
}if (true) break;

case 7:
//C
this.state = 10;
 //BA.debugLineNum = 92;BA.debugLine="LogColor(\"b4x網站正常!!\",0xFF0733FC)";
anywheresoftware.b4a.keywords.Common.LogImpl("03735570","b4x網站正常!!",((int)0xff0733fc));
 //BA.debugLineNum = 93;BA.debugLine="IsOK=True";
_isok = anywheresoftware.b4a.keywords.Common.True;
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 95;BA.debugLine="IsOK=False";
_isok = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 96;BA.debugLine="LogColor(\"b4x網站有問題???\",0xFF0733FC)";
anywheresoftware.b4a.keywords.Common.LogImpl("03735574","b4x網站有問題???",((int)0xff0733fc));
 if (true) break;

case 10:
//C
this.state = -1;
;
 //BA.debugLineNum = 99;BA.debugLine="LogColor(\"download02 Finish~~~\",0xFF0733FC)";
anywheresoftware.b4a.keywords.Common.LogImpl("03735577","download02 Finish~~~",((int)0xff0733fc));
 //BA.debugLineNum = 100;BA.debugLine="StopMessageLoop					'停止程序";
anywheresoftware.b4a.keywords.Common.StopMessageLoop(ba);
 //BA.debugLineNum = 104;BA.debugLine="Return IsOK";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(_isok));return;};
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static void  _xdownload01() throws Exception{
ResumableSub_xDownload01 rsub = new ResumableSub_xDownload01(null);
rsub.resume(ba, null);
}
public static class ResumableSub_xDownload01 extends BA.ResumableSub {
public ResumableSub_xDownload01(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
boolean _success = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 29;BA.debugLine="LogColor(\"xDownload01 before\",0xFFFC07CE)";
anywheresoftware.b4a.keywords.Common.LogImpl("03538945","xDownload01 before",((int)0xfffc07ce));
 //BA.debugLineNum = 31;BA.debugLine="wait for (download01) Complete (success As Boolea";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _download01());
this.state = 1;
return;
case 1:
//C
this.state = -1;
_success = (boolean) result[0];
;
 //BA.debugLineNum = 32;BA.debugLine="LogColor(\"下載完成: \"&success,0xFFFC07CE)";
anywheresoftware.b4a.keywords.Common.LogImpl("03538948","下載完成: "+BA.ObjectToString(_success),((int)0xfffc07ce));
 //BA.debugLineNum = 34;BA.debugLine="LogColor(\"xDownload01 after\",0xFFFC07CE)";
anywheresoftware.b4a.keywords.Common.LogImpl("03538950","xDownload01 after",((int)0xfffc07ce));
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _complete(boolean _success) throws Exception{
}
public static void  _xdownload02() throws Exception{
ResumableSub_xDownload02 rsub = new ResumableSub_xDownload02(null);
rsub.resume(ba, null);
}
public static class ResumableSub_xDownload02 extends BA.ResumableSub {
public ResumableSub_xDownload02(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
boolean _success = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 65;BA.debugLine="LogColor(\"xDownload02 before\",0xFF0733FC)";
anywheresoftware.b4a.keywords.Common.LogImpl("03670017","xDownload02 before",((int)0xff0733fc));
 //BA.debugLineNum = 67;BA.debugLine="wait for (download02) Complete (success As Boolea";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _download02());
this.state = 1;
return;
case 1:
//C
this.state = -1;
_success = (boolean) result[0];
;
 //BA.debugLineNum = 68;BA.debugLine="LogColor(\"下載完成: \"&success,0xFF0733FC)";
anywheresoftware.b4a.keywords.Common.LogImpl("03670020","下載完成: "+BA.ObjectToString(_success),((int)0xff0733fc));
 //BA.debugLineNum = 70;BA.debugLine="LogColor(\"xDownload02 after\",0xFF0733FC)";
anywheresoftware.b4a.keywords.Common.LogImpl("03670022","xDownload02 after",((int)0xff0733fc));
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
}
