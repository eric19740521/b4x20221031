package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends Object{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4a.StandardBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) throws Exception{
        try {
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            ba.raiseEvent(null, "appstart", (Object)args);
        } catch (Throwable t) {
			BA.printException(t, true);
		
        } finally {
            anywheresoftware.b4a.keywords.Common.LogDebug("Program terminated (StartMessageLoop was not called).");
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static String  _appstart(String[] _args) throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="Sub AppStart (Args() As String)";
 //BA.debugLineNum = 12;BA.debugLine="Log(\"Hello world!!!\")";
anywheresoftware.b4a.keywords.Common.LogImpl("665537","Hello world!!!",0);
 //BA.debugLineNum = 13;BA.debugLine="StartMessageLoop";
anywheresoftware.b4a.keywords.Common.StartMessageLoop(ba);
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public static void  _newtest() throws Exception{
ResumableSub_NewTest rsub = new ResumableSub_NewTest(null);
rsub.resume(ba, null);
}
public static class ResumableSub_NewTest extends BA.ResumableSub {
public ResumableSub_NewTest(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
boolean _finish = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = -1;
 //BA.debugLineNum = 19;BA.debugLine="Log(\"before\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6131073","before",0);
 //BA.debugLineNum = 20;BA.debugLine="Wait For (Test) Complete (Finish As Boolean)";
anywheresoftware.b4a.keywords.Common.WaitFor("complete", ba, this, _test());
this.state = 1;
return;
case 1:
//C
this.state = -1;
_finish = (boolean) result[0];
;
 //BA.debugLineNum = 21;BA.debugLine="Log(\"after\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6131075","after",0);
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _complete(boolean _finish) throws Exception{
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="NewTest";
_newtest();
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.keywords.Common.ResumableSubWrapper  _test() throws Exception{
ResumableSub_Test rsub = new ResumableSub_Test(null);
rsub.resume(ba, null);
return (anywheresoftware.b4a.keywords.Common.ResumableSubWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.keywords.Common.ResumableSubWrapper(), rsub);
}
public static class ResumableSub_Test extends BA.ResumableSub {
public ResumableSub_Test(b4j.example.main parent) {
this.parent = parent;
}
b4j.example.main parent;
int _i = 0;
int step1;
int limit1;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
{
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,null);return;}
case 0:
//C
this.state = 1;
 //BA.debugLineNum = 24;BA.debugLine="For i = 1 To 60";
if (true) break;

case 1:
//for
this.state = 4;
step1 = 1;
limit1 = (int) (60);
_i = (int) (1) ;
this.state = 5;
if (true) break;

case 5:
//C
this.state = 4;
if ((step1 > 0 && _i <= limit1) || (step1 < 0 && _i >= limit1)) this.state = 3;
if (true) break;

case 6:
//C
this.state = 5;
_i = ((int)(0 + _i + step1)) ;
if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 25;BA.debugLine="Log(i)";
anywheresoftware.b4a.keywords.Common.LogImpl("6196610",BA.NumberToString(_i),0);
 //BA.debugLineNum = 26;BA.debugLine="Sleep(20)    '<<-- Displaying Only First i=1";
anywheresoftware.b4a.keywords.Common.Sleep(ba,this,(int) (20));
this.state = 7;
return;
case 7:
//C
this.state = 6;
;
 if (true) break;
if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 28;BA.debugLine="Log(\"For/Next Finished\")";
anywheresoftware.b4a.keywords.Common.LogImpl("6196613","For/Next Finished",0);
 //BA.debugLineNum = 29;BA.debugLine="StopMessageLoop";
anywheresoftware.b4a.keywords.Common.StopMessageLoop(ba);
 //BA.debugLineNum = 30;BA.debugLine="Return True";
if (true) {
anywheresoftware.b4a.keywords.Common.ReturnFromResumableSub(this,(Object)(anywheresoftware.b4a.keywords.Common.True));return;};
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
}
